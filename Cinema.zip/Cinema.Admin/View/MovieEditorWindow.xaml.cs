﻿using System.Windows;

namespace Cinema.Admin.View
{
    /// <summary>
    /// Interaction logic for MovieEditorWindow.xaml
    /// </summary>
    public partial class MovieEditorWindow : Window
    {
        public MovieEditorWindow()
        {
            InitializeComponent();
        }
    }
}
