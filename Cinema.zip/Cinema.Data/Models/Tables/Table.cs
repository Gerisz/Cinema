﻿namespace Cinema.Data.Models.Tables
{
    public class Table
    {
        public int Id { get; set; }
    }
}
