﻿namespace Cinema.Data.Models.Tables.Enums
{
    public enum Status
    {
        Free = 1,
        Reserved,
        Sold
    }
}
