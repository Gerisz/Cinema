﻿namespace Cinema.Data.Models.DTOs
{
    public class UserLogin
    {
        ///<example>username</example>
        public String UserName { get; set; } = null!;

        /// <example>password</example>
        public String Password { get; set; } = null!;
    }
}
